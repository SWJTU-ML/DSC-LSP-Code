# DSC-LSP<br>
# Run<br>
Use the command “python main.py” to run the code. If you want to change the dataset, you can change it in the data.py and main.py files (in the load_mydata function in data.py and at line 77 in the main.py file).
# Requirements<br>
  python == 3.10.9<br>
  numpy == 1.25.0<br>
  torch == 2.0.1<br>
  scipy == 1.11.4<br>
